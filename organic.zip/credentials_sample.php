<?php
$cred = array(
    'dev' => array(
        'db_name' => '',
        'db_user' => '',
        'db_password' => '',
        'db_host' => '',
    ),
    'prod' => array(
        'db_name' => '',
        'db_user' => '',
        'db_password' => '',
        'db_host' => '',
    ),
);