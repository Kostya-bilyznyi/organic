<?php

$cred = array(
    'dev' => array(
        'db_name' => 'organic',
        'db_user' => 'mysql',
        'db_password' => 'mysql',
        'db_host' => 'localhost',
    ),
    'prod' => array(
        'db_name' => 'organic',
        'db_user' => 'organic',
        'db_password' => 'vQ6jN9qK6qiB7z',
        'db_host' => 'localhost',
    ),
);